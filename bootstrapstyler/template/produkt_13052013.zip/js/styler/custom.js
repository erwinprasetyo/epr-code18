$(document).ready(function () {
	$('.carousel').carousel({
	  interval: false
	})
});